#define WIN32_LEAN_AND_MEAN 

//#define NOCLIPBOARD
#define NOCOMM
#define NOCTLMGR
#define NOCOLOR
#define NODEFERWINDOWPOS
#define NODESKTOP
#define NODRAWTEXT
#define NOEXTAPI
#define NOGDICAPMASKS
#define NOHELP
#define NOICONS
#define NOTIME
#define NOIMM
#define NOKANJI
#define NOKERNEL
#define NOKEYSTATES
#define NOMCX
#define NOMEMMGR
#define NOMENUS
//#define NOMETAFILE
#define NOMSG
#define NONCMESSAGES
#define NOPROFILER
#define NORASTEROPS
#define NORESOURCE
#define NOSCROLL
//#define NOSERVICE		/* Windows NT Services */
#define NOSHOWWINDOW
#define NOSOUND
#define NOSYSCOMMANDS
#define NOSYSMETRICS
#define NOSYSPARAMS
#define NOTEXTMETRIC
#define NOVIRTUALKEYCODES
#define NOWH
#define NOWINDOWSTATION
#define NOWINMESSAGES
#define NOWINOFFSETS
#define NOWINSTYLES
#define OEMRESOURCE
#pragma warning(disable : 4996)

#include <windows.h>
#include <tchar.h>
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <io.h>
#include <WinSock2.h>

#if !defined(_Wp64)
#define DWORD_PTR DWORD
#define LONG_PTR LONG
#define INT_PTR INT
#endif

#define DATALEN 56
#define KEYLEN 8
typedef struct _RECORD {
	TCHAR key[KEYLEN];
	TCHAR data[DATALEN];
} RECORD;

#define RECSIZE sizeof (RECORD)

RECORD ReadRecord(HANDLE STDInput, int spot_o) {
	DWORD BIn;
	RECORD temp;
	LARGE_INTEGER spot;
	spot.QuadPart = spot_o * 64;
	SetFilePointerEx(STDInput, spot, NULL, FILE_BEGIN);
	ReadFile(STDInput, &temp, RECSIZE, &BIn, NULL);
	return temp;
}

void WriteRecord(HANDLE STDOutput, int spot_o, RECORD to_write) {
	DWORD Bout;

	LARGE_INTEGER spot;
	spot.QuadPart = spot_o * 64;
	SetFilePointerEx(STDOutput, spot, NULL, FILE_BEGIN);
	WriteFile(STDOutput, &to_write, RECSIZE, &Bout, NULL);
	//return temp;
}

void swap(RECORD *a, RECORD *b) { // using the actual value to do the swap 
	RECORD temp = *a;
	*a = *b;
	*b = temp;
}


int partition(RECORD arr[], int low, int high) {
	RECORD pivot = arr[high];  
	int i = (low - 1);  

	for (int j = low; j < high; j++) {
		
		if (strcmp(arr[j].key, pivot.key) < 0) {
			i++;  
			swap(&arr[i], &arr[j]);
			
		}
	}
	swap(&arr[i+1], &arr[high]);
	

	return (i + 1);
}

void Quicksort(RECORD arr[], int low, int high) {
	if (low < high) {
		
		int pi = partition(arr, low, high);

		// sort elements before and after partition
		Quicksort(arr, low, pi - 1);
		Quicksort(arr, pi + 1, high);
	}
}

typedef struct threads_rec
{
	int low;
	int high;
	int mid;
	int processes;
	HANDLE h_source;
	HANDLE h_dest;
	
}threads_rec, * record1;

WORD WINAPI DoWork(record1);

int _tmain(int argc, LPTSTR argv[])
{

	SECURITY_ATTRIBUTES stdOutSA = /* SA for inheritable handle. */
	{ sizeof(SECURITY_ATTRIBUTES), NULL, TRUE };

	HANDLE* hProc;  /* Pointer to an array of proc handles. */
	HANDLE* hOutFiles;
	typedef struct { TCHAR tempFile[MAX_PATH]; } PROCFILE;
	PROCFILE* LeftIn; /* Pointer to array of temp file names. */
	PROCFILE* LeftOut; /* Pointer to array of temp file names. */
	TCHAR commandLine[200];
	HANDLE hInLeftTempFile, hOutLeftTempFile, hInRightTempFile, hOutRightTempFile;
	RECORD data;
	HANDLE STDInput, STDOutput;
	LARGE_INTEGER FileSize;
	DWORD BIn, Bout;
	PROCESS_INFORMATION processInfo;
	STARTUPINFO startUpSearch, startUp;
	STDInput = GetStdHandle(STD_INPUT_HANDLE);
	STDOutput = GetStdHandle(STD_OUTPUT_HANDLE);
	HANDLE hOutMapChild;
	

	int processes;  // use for extra credit
	LARGE_INTEGER spot;
	spot.QuadPart = 0;
	processes = atoi(argv[1]);

	GetFileSizeEx(STDInput, &FileSize);

	int num_items = (FileSize.QuadPart) / 64;
	SYSTEM_INFO sysinfo;
	GetSystemInfo(&sysinfo);
	int numCPU = sysinfo.dwNumberOfProcessors;

	int tracker = 1;					
	if (argc == 1)						
	{									
		while (tracker < numCPU)		
		{								
			tracker *= 2;				
		}								
		processes = tracker;			// gets the cores of the computer
	}									
	else                                
	{									
		processes = atoi(argv[1]); 		
	}


	if (processes == 1 && argc == 2)
	{
		LARGE_INTEGER spot;
		spot.QuadPart = 0;
		SetFilePointerEx(STDInput, spot, NULL, FILE_BEGIN);
		//hOutMapChild = atoi(argv[3]);
		hOutMapChild = CreateFileMapping(STDOutput, &stdOutSA, PAGE_READWRITE, FileSize.HighPart, FileSize.LowPart, NULL);
		int low = 0;
		int high = (FileSize.QuadPart / 64) - 1;
		RECORD* pOutM_view_File = MapViewOfFile(hOutMapChild, FILE_MAP_WRITE, 0, 0, FileSize.QuadPart);

		for (int i = 0; i < num_items; i++)
		{
			ReadFile(STDInput, &pOutM_view_File[i], RECSIZE, &BIn, NULL);

		}
		Quicksort(pOutM_view_File, low, high);

		return;
	}
	/*else if (processes == 1 && argc > 2)
	{
		HANDLE hdes_Map = atoi(argv[3]);
		int Low = atoi(argv[4]);
		int High = atoi(argv[5]);
		RECORD* hOutView_Des = MapViewOfFile(hdes_Map, FILE_MAP_WRITE, 0, 0, FileSize.QuadPart);
		Quicksort(hOutView_Des, Low, High);
	}*/

	else if (processes > 1 && argc == 2)// root call
	{

		GetStartupInfo(&startUpSearch);
		GetStartupInfo(&startUp);
		HANDLE hTemp_File;
		HANDLE hproc1, hproc2;

		hTemp_File =
			CreateFile("tempfile.txt",                            
				GENERIC_READ | GENERIC_WRITE,
				FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, &stdOutSA,
				CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

		LARGE_INTEGER spot;
		spot.QuadPart = 0;
		SetFilePointerEx(STDInput, spot, NULL, FILE_BEGIN);

		HANDLE Mem_SourceIn = CreateFileMapping(hTemp_File, &stdOutSA, PAGE_READWRITE, FileSize.HighPart, FileSize.LowPart, NULL);
		HANDLE Mem_DesOut = CreateFileMapping(STDOutput, &stdOutSA, PAGE_READWRITE, FileSize.HighPart, FileSize.LowPart, NULL);


		RECORD* View_InFile = MapViewOfFile(Mem_SourceIn, FILE_MAP_WRITE, 0, 0, FileSize.QuadPart);
		DWORD error = GetLastError();
		RECORD* View_OutFile = MapViewOfFile(Mem_DesOut, FILE_MAP_WRITE, 0, 0, FileSize.QuadPart);
		error = GetLastError();

		RECORD Copy;
		for (int i = 0; i <= num_items; i++)
		{

			ReadFile(STDInput, &Copy, RECSIZE, &BIn, NULL);
			View_InFile[i] = Copy;
			View_OutFile[i] = Copy;
			
		}

		int low = 0;
		int high = (FileSize.QuadPart / 64);
		int mid = (low + high) / 2;

		//sprintf(commandLine, _T("sortmmp %d %d %d %d %d"), processes / 2, Mem_DesOut, Mem_SourceIn, low, mid);
		threads_rec recordinfo;
		recordinfo.low = 0;
		recordinfo.mid = (low+high) /2;
		recordinfo.high = mid;
		recordinfo.h_source = Mem_DesOut;
		recordinfo.h_dest = Mem_SourceIn;
		recordinfo.processes = processes /2;


		hproc1 = (HANDLE)_beginthreadex(NULL, 0, DoWork, &recordinfo, 0, NULL);
		

		//sprintf(commandLine, _T("sortmmp %d %d %d %d %d"), processes / 2, Mem_DesOut, Mem_SourceIn, mid + 1, high);
		threads_rec recordinfo1;
		recordinfo1.low = mid+1;
		recordinfo1.mid = (low + high) / 2;
		recordinfo1.high = high;
		recordinfo1.h_source = Mem_DesOut;
		recordinfo1.h_dest = Mem_SourceIn;
		recordinfo1.processes = processes / 2;

		hproc2 = (HANDLE)_beginthreadex(NULL, 0, DoWork, &recordinfo1, 0, NULL);

		WaitForSingleObject(hproc1, INFINITE);  
		WaitForSingleObject(hproc2, INFINITE);


		int length;
		int totalright = high;
		int totalleft = mid;
		length = FileSize.QuadPart / 64;
		int  track = low, trackLeft = 0, trackRight = mid + 1;

		while (trackLeft <= totalleft && trackRight <= totalright)
		{

			if (strcmp(View_InFile[trackLeft].key, View_InFile[trackRight].key, 8) < 0)
			{
				View_OutFile[track] = View_InFile[trackLeft];
				track++;
				trackLeft++;

			}
			else
			{
				View_OutFile[track] = View_InFile[trackRight];
				track++;
				trackRight++;


			}
		}
		while (trackLeft <= totalleft)
		{

			View_OutFile[track] = View_InFile[trackLeft];
			track++;
			trackLeft++;

		}

		while (trackRight <= totalright)
		{

			View_OutFile[track] = View_InFile[trackRight];
			track++;
			trackRight++;

		}

		UnmapViewOfFile(View_OutFile);
		UnmapViewOfFile(View_InFile);
		CloseHandle(Mem_SourceIn);
		CloseHandle(Mem_DesOut);
		DeleteFile("tempfile.txt");

	}
	
	/*else if (processes > 1)
	{

		GetStartupInfo(&startUpSearch);
		GetStartupInfo(&startUp);
		HANDLE hSource_Map = atoi(argv[2]);
		HANDLE hdes_Map = atoi(argv[3]);
		int low = atoi(argv[4]);
		int high = atoi(argv[5]);
		int mid = (low + high) / 2;
		DWORD error;

		sprintf(commandLine, _T("sortmmp %d %d %d %d %d"), processes / 2, hdes_Map, hSource_Map, low, mid);
		if (!CreateProcess(NULL, commandLine, NULL, NULL,
			TRUE, 0, NULL, NULL, &startUpSearch, &processInfo))
			printf("ProcCreate failed.");
		int process = processInfo.hProcess;

		sprintf(commandLine, _T("sortmmp %d %d %d %d %d"), processes / 2, hdes_Map, hSource_Map, mid + 1, high);
		if (!CreateProcess(NULL, commandLine, NULL, NULL,
			TRUE, 0, NULL, NULL, &startUpSearch, &processInfo))
			printf("ProcCreate failed.");
		int process2 = processInfo.hProcess;

		WaitForSingleObject(process, INFINITE);
		WaitForSingleObject(process2, INFINITE);

		RECORD* View_InMap = MapViewOfFile(hSource_Map, FILE_MAP_WRITE, 0, 0, FileSize.QuadPart);
		error = GetLastError();
		RECORD* View_OutMap = MapViewOfFile(hdes_Map, FILE_MAP_WRITE, 0, 0, FileSize.QuadPart);
		error = GetLastError();


		int length;
		int totalright = high;
		int totalleft = mid;
		length = FileSize.QuadPart / 64;
		int  track = low, trackLeft = low, trackRight = mid + 1;

		while (trackLeft <= totalleft && trackRight <= totalright)
		{

			if (strcmp(View_InMap[trackLeft].key, View_InMap[trackRight].key, 8) < 0)
			{
				View_OutMap[track] = View_InMap[trackLeft];
				track++;
				trackLeft++;

			}
			else
			{
				View_OutMap[track] = View_InMap[trackRight];
				track++;
				trackRight++;


			}
		}
		while (trackLeft <= totalleft)
		{

			View_OutMap[track] = View_InMap[trackLeft];
			track++;
			trackLeft++;

		}

		while (trackRight <= totalright)
		{

			View_OutMap[track] = View_InMap[trackRight];
			track++;
			trackRight++;

		}

		UnmapViewOfFile(View_OutMap);
		UnmapViewOfFile(View_InMap);
		CloseHandle(hSource_Map);
		CloseHandle(hdes_Map);


	}*/
		return 0;
	
}

WORD WINAPI DoWork(record1 who)
{
	LARGE_INTEGER FileSize;
	HANDLE STDInput;
	STDInput = GetStdHandle(STD_INPUT_HANDLE);
	GetFileSizeEx(STDInput, &FileSize);
	threads_rec r_child, l_child;
	HANDLE right_c, left_c;
	

	if (who->processes == 1)
	{
		RECORD* View_OutFile = MapViewOfFile(who->h_dest, FILE_MAP_WRITE, 0, 0, FileSize.QuadPart);
		Quicksort(View_OutFile, who->low, who->high);

	}
	else
	{ 
		RECORD* View_InFile = MapViewOfFile(who->h_source, FILE_MAP_WRITE, 0, 0, FileSize.QuadPart);
		//DWORD error = GetLastError();
		RECORD* View_OutFile = MapViewOfFile(who->h_dest, FILE_MAP_WRITE, 0, 0, FileSize.QuadPart);
		//error = GetLastError();
		int midd = (who->low + who->high) / 2;
		r_child.low = midd + 1;
		r_child.high = who->high;
		r_child.h_dest = who->h_source;
		r_child.h_source = who->h_dest;
		r_child.processes = who->processes/2;

		l_child.low = who->low;
		l_child.high = midd;
		l_child.h_dest = who->h_source;
		l_child.h_source = who->h_dest;
		l_child.processes = who->processes / 2;

		right_c = (HANDLE)_beginthreadex(NULL, 0, DoWork, &r_child, 0, NULL);
		left_c = (HANDLE)_beginthreadex(NULL, 0, DoWork, &l_child, 0, NULL);

		WaitForSingleObject(right_c, INFINITE);
		WaitForSingleObject(left_c, INFINITE);


		int length;
		int totalright = who->high;
		int totalleft = midd;
		//length = FileSize.QuadPart / 64;
		int  track = who->low, trackLeft = who->low, trackRight = midd + 1;

		while (trackLeft <= totalleft && trackRight <= totalright)
		{

			if (strcmp(View_InFile[trackLeft].key, View_InFile[trackRight].key, 8) < 0)
			{
				View_OutFile[track] = View_InFile[trackLeft];
				track++;
				trackLeft++;

			}
			else
			{
				View_OutFile[track] = View_InFile[trackRight];
				track++;
				trackRight++;


			}
		}
		while (trackLeft <= totalleft)
		{

			View_OutFile[track] = View_InFile[trackLeft];
			track++;
			trackLeft++;

		}

		while (trackRight <= totalright)
		{

			View_OutFile[track] = View_InFile[trackRight];
			track++;
			trackRight++;

		}

		UnmapViewOfFile(View_OutFile);
		UnmapViewOfFile(View_InFile);



	}




}